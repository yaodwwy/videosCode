<template>
	<div>
		<Navs />
		demo
	</div>
</template>

<script>
	
import Navs from "./nav"

export default {
	name:"demo",
	data(){
		return{

		}
	},
	components:{
    	Navs
  	}
}


</script>

<style>
	
</style>