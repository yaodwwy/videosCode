<template>
	<div>
		{{ desc }}
	</div>
</template>

<script>
	
export default{
	name:"rightsecond",
	data(){
		return{

		}
	},
	props:{
		desc:{
			type:String,
			default:"默认值"
		}
	}
}	

</script>

<style>
	
</style>