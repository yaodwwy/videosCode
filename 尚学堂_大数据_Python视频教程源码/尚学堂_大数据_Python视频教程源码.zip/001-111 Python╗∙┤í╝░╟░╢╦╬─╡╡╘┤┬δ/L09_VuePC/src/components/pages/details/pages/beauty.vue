<template>
	<div>
		beauty
	</div>
</template>
<script>
	
export default{
	name:"beauty",
	data(){
		return{

		}
	}
}	

</script>

<style scoped>
	
</style>