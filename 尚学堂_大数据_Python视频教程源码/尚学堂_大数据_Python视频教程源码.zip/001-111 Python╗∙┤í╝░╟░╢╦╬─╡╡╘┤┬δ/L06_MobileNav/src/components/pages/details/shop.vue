<template>
	<div>
		<div>超市的详情</div>
	</div>
</template>
<script>
	
export default{
	name:"mine",
	data(){
		return{

		}
	}
}

</script>

<style>
	
</style>