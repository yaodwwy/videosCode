<template>
	<div>
		我是热门的子页面
	</div>
</template>

<script>
	

export default {
	name:"hotson",
	data(){
		return{

		}
	}
}


</script>

<style>
	
</style>