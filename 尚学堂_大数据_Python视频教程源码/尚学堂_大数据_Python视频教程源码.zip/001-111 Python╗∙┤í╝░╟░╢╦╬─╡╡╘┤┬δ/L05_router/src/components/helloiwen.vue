<template>
	<div>iwen</div>
</template>

<script>
	
export default{
	name:"iwen",
	data(){
		return{

		}
	}
}

</script>
<style>
	
</style>