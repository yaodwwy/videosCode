<template>
	<div>
		<!-- category、mine、tuijian -->
		<router-view></router-view>
	</div>
</template>
<script>
	
export default{
	name:"layout",
	data(){
		return{

		}
	}
}

</script>

<style>
	
</style>