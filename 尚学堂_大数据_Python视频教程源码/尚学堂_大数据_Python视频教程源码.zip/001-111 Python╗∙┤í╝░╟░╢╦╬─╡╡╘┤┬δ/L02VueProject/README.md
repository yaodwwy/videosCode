1.安装node ：https://nodejs.org/en/
2.安装cnpm ：npm install -g cnpm --registry=https://registry.npm.taobao.org
3.安装webpack ：npm install -g webpack
4.安装vue-cli ：npm install --global vue-cli
5.创建项目：vue init webpack my-project
6.安装项目依赖 ：npm install
7.运行项目 : npm run dev



项目介绍：
	源代码：src
	main.js：入口文件
	App.vue：主组件  所有的vue组件都是.vue结束的
	components:存放所有的vue组件
	assets：资源文件夹  里面可以放置，img ，css等等内容


Vue组件：
	一个组件有三个部分组成
	template：标签部分(html)
	script：逻辑部分(js)
	style：样式部分(css)

	https://packagecontrol.io/installation