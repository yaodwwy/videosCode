<template>
	<div>
		cake
	</div>
</template>
<script>
	
export default{
	name:"cake",
	data(){
		return{

		}
	}
}	

</script>

<style scoped>
	
</style>