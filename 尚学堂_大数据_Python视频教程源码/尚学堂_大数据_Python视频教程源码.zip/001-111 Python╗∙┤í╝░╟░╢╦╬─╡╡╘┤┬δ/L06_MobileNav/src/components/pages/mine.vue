<template>
	<div>
		<div>我是我的页面</div>
		<Navs />
	</div>
</template>
<script>
	
import Navs from  "./nav"	
export default{
	name:"mine",
	data(){
		return{

		}
	},
	components:{
		Navs
	}
}

</script>

<style>
	
</style>