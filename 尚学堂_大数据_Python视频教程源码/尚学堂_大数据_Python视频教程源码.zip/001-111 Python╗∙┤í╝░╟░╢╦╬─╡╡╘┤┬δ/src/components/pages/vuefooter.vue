<template>
	<div>
		<div class="app-foot">
            人如蜉蝣于天地，朝生暮死
        </div>
	</div>
</template>
<script>
	
export default{
	name:"footer",
	data(){
		return {

		}
	}
}	

</script>

<style scoped>
.app-foot {
  text-align: center;
  height: 80px;
  width: 100%;
  line-height: 80px;
  background: #e3e4e8;
  clear: both;
  margin-top: 30px;
}	
</style>