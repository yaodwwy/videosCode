<template>
	<div>
		{{ t2 }}
	</div>
</template>
<script>
	
export default{
	name:"pageleft",
	data(){
		return{
			
		}
	},
	props:{
		t2:{
			type:String,
			default:'默认值'
		}
	}
}	

</script>
<style>
	

</style>