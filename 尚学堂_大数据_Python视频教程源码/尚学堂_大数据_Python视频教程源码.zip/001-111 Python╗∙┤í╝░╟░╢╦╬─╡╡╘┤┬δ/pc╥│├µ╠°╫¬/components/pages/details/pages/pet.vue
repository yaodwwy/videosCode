<template>
	<div>
		pet
	</div>
</template>
<script>
	
export default{
	name:"pet",
	data(){
		return{

		}
	}
}	

</script>

<style scoped>
	
</style>