<template>
	<div class="footer">
		我是页面的底部
	</div>
</template>
<script>
	
export default{
	name:"pageheader",
	data(){
		return{
			
		}
	}
}	

</script>
<style>

.footer{
	width: 100%;
	height: 200px;
	background-color: green;
}
	
</style>