<template>
	<div>
		<div>我是分类页面</div>
		<Navs />
	</div>
</template>
<script>

import Navs from  "./nav"		

export default{
	name:"category",
	data(){
		return{

		}
	},
	components:{
		Navs
	}
}

</script>

<style>


</style>