<template>
	<router-view />
</template>
<script>
	
export default{
	name:"layout",
	data(){
		return {

		}
	}
}	

</script>

<style>
	
</style>
