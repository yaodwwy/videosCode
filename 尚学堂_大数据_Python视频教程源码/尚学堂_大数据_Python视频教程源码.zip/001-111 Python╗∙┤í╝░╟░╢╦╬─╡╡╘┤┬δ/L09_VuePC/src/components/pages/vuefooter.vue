<template>
	<div>
		<div class="app-foot">
            寒冬凛至，20年前如此，现在也一样。人如蜉蝣于天地，朝生暮死,什么都不用做，得一日醉生梦死，得一日美人解忧，就这样吧，瞎**活
        </div>
	</div>
</template>
<script>
	
export default{
	name:"footer",
	data(){
		return {

		}
	}
}	

</script>

<style scoped>
.app-foot {
  text-align: center;
  height: 80px;
  width: 100%;
  line-height: 80px;
  background: #e3e4e8;
  clear: both;
  margin-top: 30px;
}	
</style>