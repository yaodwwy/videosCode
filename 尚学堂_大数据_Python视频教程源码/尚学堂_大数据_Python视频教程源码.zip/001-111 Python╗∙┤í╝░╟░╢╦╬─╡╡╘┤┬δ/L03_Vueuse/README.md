1.模板：
	{{  }}：单向数据绑定,只能存在单行语句
	v-bind:动态添加属性

2.条件渲染：
	v-if
	v-show

3.v-for循环
	v-for
	
4.事件
	v-on绑定事件

5.计算属性
	computed

6.组件
	组件的嵌套
	组件的数据传递
		1.父传子
			props
		2.子传父
			$emit(自定义事件)

7.双向数据绑定
	v-model