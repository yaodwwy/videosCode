<template>
	<div>
		jewellery
	</div>
</template>
<script>
	
export default{
	name:"jewellery",
	data(){
		return{

		}
	}
}	

</script>

<style scoped>
	
</style>